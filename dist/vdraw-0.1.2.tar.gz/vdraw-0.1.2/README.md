# V-Draw

V-Draw is a library with help tools for segmentation tasks.


```
pip install vdraw
```

Documentation can be found [here](https://vdraw-doc.streamlit.app/)

Project is in development phase, but some usefull functions are already added.